package com.example.tap_u5_ejemplo1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    //VARIABLES
    var num =9
    var suel = 1200.99  //Double
    var altu = 1.8f
    var descCasa = "Allende 200" //String
    var resu = true //boolean


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btn1.setOnClickListener {
            var nom = ed1.text.toString()

            if (nom.isEmpty()){
                AlertDialog.Builder(this)
                    .setTitle("¡ERROR!")
                    .setMessage("Debes Poner Un Nombre En El Campo De Texto")
                    .setPositiveButton("OK",{d,i -> d.dismiss()})
                    .show()

            }else {


                var alt = AlertDialog.Builder(this)
                alt.setTitle("ATENCION")
                alt.setMessage("Hola, ${nom} Como Estas")
                alt.setPositiveButton("ACEPTAR", { d, i -> d.dismiss() })

                alt.setNegativeButton("CANCELAR", { d, i -> d.cancel() })
                alt.show()
            }
        }
        radio1.setOnClickListener {
            Toast.makeText(this,"Ud Es Casado", Toast.LENGTH_LONG).show()
        }
        radio2.setOnClickListener {
            Toast.makeText(this,"Ud Es Soltero", Toast.LENGTH_LONG).show()
        }
    }

}